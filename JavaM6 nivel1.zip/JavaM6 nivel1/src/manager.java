
public class manager extends persona{

	public manager(String nom, double sue) {
		super(nom, sue);
		// TODO Auto-generated constructor stub
		setPorcentaje(10);
	
	}
	
}
