

public class Boss extends persona {

	

	public Boss(String nom, double sue) {
		super(nom, sue);
		setPorcentaje(50);
		
		
	}

	

}
