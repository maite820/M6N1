
public class voluntario extends persona{

	public voluntario(String nom, double sue) {
		super(nom, sue);
		// TODO Auto-generated constructor stub
		setPorcentaje(-100);
	}

}
