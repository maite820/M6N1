
public class Empleado extends persona{

	public Empleado(String nom, double sue) {
		super(nom, sue);
		// TODO Auto-generated constructor stub
		setPorcentaje(-15);
	}

}
